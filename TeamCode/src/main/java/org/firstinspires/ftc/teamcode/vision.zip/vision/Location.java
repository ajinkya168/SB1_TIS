package org.firstinspires.ftc.teamcode.vision;

public enum Location {
    LEFT, CENTER, RIGHT, BLUE, RED, FAR, CLOSE
}
